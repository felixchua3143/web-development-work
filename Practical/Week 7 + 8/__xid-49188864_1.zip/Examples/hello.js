function sayhello(){
	alert("Hello, how are you?");
	document.write("<span id='terrible'>Hey, don't ignore me!</span>");
}
